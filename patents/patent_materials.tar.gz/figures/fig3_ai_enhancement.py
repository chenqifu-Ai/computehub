#!/usr/bin/env python3
"""
图3：生成式AI数据增强流程图 - 生成脚本
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

fig, ax = plt.subplots(figsize=(12, 6))
ax.set_xlim(0, 10)
ax.set_ylim(0, 6)
ax.axis('off')

# 定义流程步骤
steps = [
    ("原始数据输入\n(可能含有缺失)", 1.5, 4.5),
    ("缺失模式分析", 4, 4.5),
    ("AI数据生成", 6.5, 4.5),
    ("生成数据输出", 9, 4.5),
    ("数据质量验证", 7.5, 2.5),
    ("领域知识约束", 4.5, 2.5)
]

# 绘制流程框
for text, x, y in steps:
    color = 'lightblue' if y == 4.5 else 'lightgreen'
    rect = patches.Rectangle((x-1.2, y-0.5), 2.4, 1.0, 
                           linewidth=2, edgecolor='black',
                           facecolor=color, alpha=0.7)
    ax.add_patch(rect)
    ax.text(x, y, text, ha='center', va='center', 
           fontsize=9, linespacing=1.2)

# 绘制主流程箭头
main_x = [1.5, 4, 6.5, 9]
for i in range(len(main_x)-1):
    ax.annotate('', xy=(main_x[i+1]-1.2, 4.5), xytext=(main_x[i]+1.2, 4.5),
               arrowprops=dict(arrowstyle='->', lw=1.5))

# 绘制反馈箭头
# AI生成 → 领域约束
ax.annotate('', xy=(4.5, 3), xytext=(6.5, 3.5),
           arrowprops=dict(arrowstyle='->', lw=1.5, connectionstyle="arc3,rad=-0.2"))

# 领域约束 → AI生成  
ax.annotate('', xy=(6.5, 3.5), xytext=(4.5, 3),
           arrowprops=dict(arrowstyle='->', lw=1.5, connectionstyle="arc3,rad=-0.2"))

# 生成输出 → 质量验证
ax.annotate('', xy=(7.5, 3), xytext=(9, 4),
           arrowprops=dict(arrowstyle='->', lw=1.5, connectionstyle="arc3,rad=0.2"))

# 质量验证 → 领域约束
ax.annotate('', xy=(4.5, 2.5), xytext=(7.5, 2.5),
           arrowprops=dict(arrowstyle='->', lw=1.5))

# 添加标题
ax.text(5, 5.5, "图3：生成式AI数据增强流程图", 
       ha='center', va='center', 
       fontsize=14, fontweight='bold')

plt.tight_layout()
plt.savefig('figure3_ai_enhancement.png', dpi=300, bbox_inches='tight', facecolor='white')
plt.savefig('figure3_ai_enhancement.pdf', bbox_inches='tight', facecolor='white')

print("图3已生成: figure3_ai_enhancement.png/pdf")