#!/usr/bin/env python3
"""
图2：多模态数据融合示意图 - 生成脚本
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.path import Path
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

fig, ax = plt.subplots(figsize=(12, 8))
ax.set_xlim(0, 10)
ax.set_ylim(0, 8)
ax.axis('off')

# 绘制三个数据源框
sources = [
    ("结构化统计数据\n- 医院统计\n- 产业数据\n- 教育数据", 2, 6),
    ("非结构化文本数据\n- 学术论文\n- 病例记录\n- 中医文献", 2, 4), 
    ("中医图像数据\n- 诊断图像\n- 药材图像", 2, 2)
]

for text, x, y in sources:
    rect = patches.Rectangle((x-0.8, y-0.6), 3.6, 1.2, 
                           linewidth=2, edgecolor='black',
                           facecolor='lightgreen', alpha=0.7)
    ax.add_patch(rect)
    ax.text(x+1, y, text, ha='center', va='center', 
           fontsize=9, linespacing=1.2)

# 绘制融合中心
center_rect = patches.Rectangle((6, 3.4), 3, 1.2, 
                              linewidth=2, edgecolor='black',
                              facecolor='lightcoral', alpha=0.7)
ax.add_patch(center_rect)
ax.text(7.5, 4, "多模态数据\n融合向量表示", 
       ha='center', va='center', fontsize=10, linespacing=1.2)

# 绘制连接线和箭头
# 从数据源到融合中心
for i, (text, x, y) in enumerate(sources):
    if i == 0:  # 上方数据源
        ax.annotate('', xy=(6, 4.6), xytext=(x+3.6, y),
                   arrowprops=dict(arrowstyle='->', lw=1.5))
    elif i == 1:  # 中间数据源
        ax.annotate('', xy=(6, 4), xytext=(x+3.6, y),
                   arrowprops=dict(arrowstyle='->', lw=1.5))
    else:  # 下方数据源
        ax.annotate('', xy=(6.5, 3.4), xytext=(x+3.6, y),
                   arrowprops=dict(arrowstyle='->', lw=1.5))

# 添加数据融合标签
ax.text(4.5, 4.8, "数据融合", ha='center', va='center', 
       fontsize=10, fontweight='bold', 
       bbox=dict(boxstyle="round,pad=0.3", facecolor="yellow", alpha=0.7))

# 添加标题
ax.text(5, 7.5, "图2：多模态数据融合示意图", 
       ha='center', va='center', 
       fontsize=14, fontweight='bold')

plt.tight_layout()
plt.savefig('figure2_data_fusion.png', dpi=300, bbox_inches='tight', facecolor='white')
plt.savefig('figure2_data_fusion.pdf', bbox_inches='tight', facecolor='white')

print("图2已生成: figure2_data_fusion.png/pdf")