#!/usr/bin/env python3
"""
图1：系统整体架构图 - 生成脚本
使用matplotlib生成专利系统架构图
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.path import Path
import numpy as np

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# 创建画布
fig, ax = plt.subplots(figsize=(12, 10))
ax.set_xlim(0, 10)
ax.set_ylim(0, 12)
ax.axis('off')

# 定义图层和位置
layers = [
    "多模态数据输入层",
    "数据预处理与融合层", 
    "生成式AI数据增强核心",
    "认知状态建模层",
    "智能指令生成层",
    "统计建模执行层",
    "多模态输出层",
    "质量监控与反馈层"
]

positions = np.linspace(11, 1, len(layers))

# 绘制各个图层
for i, (layer, y) in enumerate(zip(layers, positions)):
    # 绘制矩形框
    rect = patches.Rectangle((2, y-0.4), 6, 0.8, 
                           linewidth=2, edgecolor='black', 
                           facecolor='lightblue', alpha=0.7)
    ax.add_patch(rect)
    
    # 添加文字
    ax.text(5, y, layer, ha='center', va='center', 
           fontsize=10, fontweight='bold')
    
    # 绘制连接箭头（除了最后一层）
    if i < len(layers) - 1:
        ax.arrow(5, y-0.4, 0, -0.8, 
                head_width=0.2, head_length=0.2, 
                fc='black', ec='black', linewidth=1.5)

# 添加标题
ax.text(5, 11.5, "图1：系统整体架构图", 
       ha='center', va='center', 
       fontsize=14, fontweight='bold')

ax.text(5, 11.2, "基于生成式AI的中医药统计建模智能辅助系统",
       ha='center', va='center', fontsize=10)

# 调整布局
plt.tight_layout()

# 保存图像
plt.savefig('figure1_system_architecture.png', 
           dpi=300, bbox_inches='tight', 
           facecolor='white')
plt.savefig('figure1_system_architecture.pdf', 
           bbox_inches='tight', facecolor='white')

print("图1已生成: figure1_system_architecture.png/pdf")

# 显示图像（可选）
# plt.show()