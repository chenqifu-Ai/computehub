#!/usr/bin/env python3
"""
Qwen Proxy — 可配置的 OpenAI 兼容 API 代理
=============================================

支持三种配置方式（优先级 CLI > 环境变量 > config.yaml）：
  1. config.yaml 文件
  2. 环境变量 (TARGET, LISTEN_PORT, API_KEY, TARGET_HOST, TARGET_PORT)
  3. CLI 参数 (--target, --port, --listen, --timeout 等)

用法：
  python3 proxy.py                         # 使用 config.yaml 默认配置
  TARGET=deepseek python3 proxy.py         # 环境变量指定目标
  python3 proxy.py --target deepseek       # CLI 指定目标
  python3 proxy.py --target-host api.xxx.com --target-port 443 --ssl
"""

import json
import os
import sys
import signal
import http.server
import http.client
import http.client as httplib
import ssl as ssl_module
import urllib.parse
import argparse
from datetime import datetime, timezone, timedelta

# ═══════════════════════════════════════════════════════════
# 内置简易 YAML 解析（零依赖）
# 只解析我们 config.yaml 用到的子集
# ═══════════════════════════════════════════════════════════

def _parse_yaml(text):
    """解析简易 YAML → dict。支持注释、字符串、整数、bool、列表、嵌套。"""
    result = {}
    stack = [result]           # 当前嵌套栈
    indent_stack = [-1]        # 对应的缩进层级
    key_stack = []             # 对应的 key

    for line in text.split("\n"):
        # 去掉注释（行内 # 仅在引号外才去掉，简单处理：只去掉行首前的 #）
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        # 计算缩进（空格）
        raw_indent = len(line) - len(line.lstrip(" "))
        # 去掉行内注释（# 后面的内容）
        if "#" in stripped:
            # 简单处理：去掉第一个 # 及其后面内容
            idx = stripped.index("#")
            # 确保不是在引号内（简易处理）
            stripped = stripped[:idx].rstrip()

        if not stripped:
            continue

        # 判断是否列表项
        is_list_item = stripped.startswith("-")
        if is_list_item:
            stripped = stripped[1:].strip()

        # 解析 key: value
        if ":" in stripped and not is_list_item:
            colon_idx = stripped.index(":")
            key = stripped[:colon_idx].strip()
            value_part = stripped[colon_idx+1:].strip()

            # 处理缩进层级变化
            if value_part:
                # 有值: key: value → 直接赋值（无论缩进层级）
                # 先退到正确的层级
                while raw_indent <= indent_stack[-1] and len(stack) > 1:
                    stack.pop()
                    indent_stack.pop()
                    key_stack.pop()
                stack[-1][key] = _parse_yaml_value(value_part)
            else:
                # 无值: key: （嵌套结构开始）
                if raw_indent > indent_stack[-1]:
                    # 进一层
                    parent = {}
                    stack[-1][key] = parent
                    stack.append(parent)
                    indent_stack.append(raw_indent)
                    key_stack.append(key)
                else:
                    # 同层或出层
                    while raw_indent <= indent_stack[-1] and len(stack) > 1:
                        stack.pop()
                        indent_stack.pop()
                        key_stack.pop()
                    parent = {}
                    stack[-1][key] = parent
                    stack.append(parent)
                    indent_stack.append(raw_indent)
                    key_stack.append(key)
        elif is_list_item:
            # 列表项
            while raw_indent <= indent_stack[-1] and len(stack) > 1:
                stack.pop()
                indent_stack.pop()
                key_stack.pop()
            # 找到当前列表所在的 key
            if stack[-1] and isinstance(stack[-1], dict):
                # 找到最后一个列表类型的值
                list_key = None
                for k, v in list(stack[-1].items()):
                    if isinstance(v, list):
                        list_key = k
                        break
                if list_key is None:
                    # 没有列表，创建一个
                    list_key = "__last_list__"
                    stack[-1][list_key] = []
                stack[-1][list_key].append(_parse_yaml_value(stripped))
        else:
            # 纯值（不常见）
            pass

    return result


def _parse_yaml_value(val):
    """解析 YAML 标量值"""
    val = val.strip()
    if not val:
        return None
    # 内联列表
    if val.startswith("[") and val.endswith("]"):
        inner = val[1:-1].strip()
        if not inner:
            return []
        return [item.strip().strip("'\"").strip() for item in inner.split(",")]
    if val.lower() == "true":
        return True
    if val.lower() == "false":
        return False
    if val.lower() == "null" or val.lower() == "~":
        return None
    # 数字
    try:
        if "." in val:
            return float(val)
        return int(val)
    except ValueError:
        pass
    # 去掉引号
    if (val.startswith('"') and val.endswith('"')) or \
       (val.startswith("'") and val.endswith("'")):
        return val[1:-1]
    return val


def _load_yaml(path):
    """加载 YAML 文件，返回 dict"""
    with open(path, "r") as f:
        return _parse_yaml(f.read())


# ═══════════════════════════════════════════════════════════
# 配置加载
# ═══════════════════════════════════════════════════════════

CFG_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_FILE = os.path.join(CFG_DIR, "config.yaml")

def load_config():
    """加载配置: config.yaml → 环境变量 → CLI 参数"""
    cfg = {
        "listen_host": "0.0.0.0",
        "listen_port": 8765,
        "target": {
            "host": "58.23.129.98",
            "port": 8001,
            "api_key": "sk-78sadn09bjawde123e",
            "ssl": False,
        },
        "logging": {
            "level": "info",
            "hex_dump": False,
            "max_body_log": 2000,
            "log_file": "",
        },
        "proxy": {
            "timeout": 300,
            "allowed_models": [],
            "rate_limit": 0,
        },
    }

    # 1) 从 YAML 文件加载（内置解析器，零依赖）
    if os.path.exists(CFG_FILE):
        file_cfg = _load_yaml(CFG_FILE) or {}
        # 合并 targets
        all_targets = file_cfg.get("targets", {})
        default_name = file_cfg.get("default_target", "")
        if default_name and default_name in all_targets:
            t = all_targets[default_name]
            cfg["target"] = {
                "host": t.get("host", cfg["target"]["host"]),
                "port": t.get("port", cfg["target"]["port"]),
                "api_key": t.get("api_key", cfg["target"]["api_key"]),
                "ssl": t.get("ssl", cfg["target"]["ssl"]),
            }
        # 配置文件中的其他设置
        if "listen_port" in file_cfg:
            cfg["listen_port"] = int(file_cfg["listen_port"])
        if "listen_host" in file_cfg:
            cfg["listen_host"] = file_cfg["listen_host"]
        if "logging" in file_cfg:
            cfg["logging"].update(file_cfg["logging"])
        if "proxy" in file_cfg:
            cfg["proxy"].update(file_cfg["proxy"])

    # 2) 环境变量覆盖 (TARGET=name, 或 TARGET_HOST+ TARGET_PORT+ API_KEY)
    env_target_name = os.environ.get("TARGET", "")
    if env_target_name and os.path.exists(CFG_FILE):
        file_cfg = _load_yaml(CFG_FILE)
        all_targets = file_cfg.get("targets", {})
        if env_target_name in all_targets:
            t = all_targets[env_target_name]
            cfg["target"]["host"] = t.get("host", cfg["target"]["host"])
            cfg["target"]["port"] = t.get("port", cfg["target"]["port"])
            cfg["target"]["api_key"] = t.get("api_key", cfg["target"]["api_key"])
            cfg["target"]["ssl"] = t.get("ssl", cfg["target"]["ssl"])
        else:
            print(f"[WARN] TARGET='{env_target_name}' 在 config.yaml 中未找到, 使用默认")

    # 单独环境变量覆盖 (优先级高于 targets 里的)
    for env_key, cfg_key in [
        ("TARGET_HOST", ("target", "host")),
        ("TARGET_PORT", ("target", "port")),
        ("API_KEY", ("target", "api_key")),
        ("LISTEN_PORT", ("listen_port",)),
        ("SSL", ("target", "ssl")),
        ("TIMEOUT", ("proxy", "timeout")),
    ]:
        val = os.environ.get(env_key)
        if val is not None:
            if isinstance(cfg_key, tuple) and len(cfg_key) > 1:
                d = cfg
                for k in cfg_key[:-1]:
                    d = d[k]
                # 类型转换
                if env_key == "TARGET_PORT":
                    d[cfg_key[-1]] = int(val)
                elif env_key == "LISTEN_PORT":
                    d["listen_port"] = int(val)
                elif env_key == "SSL":
                    d[cfg_key[-1]] = val.lower() in ("true", "1", "yes")
                elif env_key == "TIMEOUT":
                    d[cfg_key[-1]] = int(val)
                else:
                    d[cfg_key[-1]] = val
            else:
                cfg["listen_port"] = int(val)

    return cfg


# ── CLI 参数解析 (最高优先级) ──

def parse_cli(cfg):
    parser = argparse.ArgumentParser(
        description="Qwen Proxy — 可配置的 OpenAI 兼容 API 代理",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s                              # 使用 config.yaml 默认
  %(prog)s --target deepseek            # 选择配置中的目标
  %(prog)s --target-host api.xxx.com --target-port 443 --ssl
  %(prog)s --listen 9999 --timeout 600  # 改端口和超时
        """,
    )
    parser.add_argument("--target", "-t", help="目标名称 (config.yaml 中定义)")
    parser.add_argument("--target-host", help="目标 IP 或域名")
    parser.add_argument("--target-port", type=int, help="目标端口")
    parser.add_argument("--api-key", help="API Key")
    parser.add_argument("--ssl", action="store_true", help="使用 HTTPS")
    parser.add_argument("--no-ssl", action="store_true", help="关闭 HTTPS")
    parser.add_argument("--listen", type=int, help="本地监听端口")
    parser.add_argument("--listen-host", default=None, help="本地监听地址")
    parser.add_argument("--timeout", type=int, help="后端请求超时 (秒)")
    parser.add_argument("--debug", action="store_true", help="Debug 模式 (hex dump)")
    parser.add_argument("--log-file", help="日志文件路径")

    args = parser.parse_args()
    if not any(vars(args).values()):
        return cfg  # 无任何 CLI 参数

    # CLI 指定 target name → 从 config.yaml 加载
    if args.target and os.path.exists(CFG_FILE):
        file_cfg = _load_yaml(CFG_FILE)
        all_targets = file_cfg.get("targets", {})
        if args.target in all_targets:
            t = all_targets[args.target]
            cfg["target"]["host"] = t.get("host", cfg["target"]["host"])
            cfg["target"]["port"] = t.get("port", cfg["target"]["port"])
            cfg["target"]["api_key"] = t.get("api_key", cfg["target"]["api_key"])
            cfg["target"]["ssl"] = t.get("ssl", cfg["target"]["ssl"])
            cfg["target"]["description"] = t.get("description", "")
        else:
            print(f"[WARN] --target '{args.target}' 未在 config.yaml 中找到, 忽略")

    # 直接覆盖目标属性
    if args.target_host:
        cfg["target"]["host"] = args.target_host
    if args.target_port is not None:
        cfg["target"]["port"] = args.target_port
    if args.api_key:
        cfg["target"]["api_key"] = args.api_key
    if args.ssl:
        cfg["target"]["ssl"] = True
    if args.no_ssl:
        cfg["target"]["ssl"] = False
    if args.listen is not None:
        cfg["listen_port"] = args.listen
    if args.listen_host:
        cfg["listen_host"] = args.listen_host
    if args.timeout is not None:
        cfg["proxy"]["timeout"] = args.timeout
    if args.debug:
        cfg["logging"]["level"] = "debug"
        cfg["logging"]["hex_dump"] = True
    if args.log_file:
        cfg["logging"]["log_file"] = args.log_file

    return cfg


# ═══════════════════════════════════════════════════════════
# 日志工具
# ═══════════════════════════════════════════════════════════

tz_cn = timezone(timedelta(hours=8))

class Logger:
    def __init__(self, cfg):
        self.level = cfg["logging"]["level"]
        self.hex_dump = cfg["logging"]["hex_dump"]
        self.max_body = cfg["logging"]["max_body_log"]
        self.log_file = cfg["logging"]["log_file"]
        self._fh = None
        if self.log_file:
            self._fh = open(self.log_file, "a")

    def ts(self):
        return datetime.now(tz_cn).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    def _write(self, tag, msg, force=False):
        prefix = f"[{self.ts()}] [{tag:>5}] "
        full = prefix + msg
        if not force and self.level == "warning" and tag not in ("WARN", "ERROR"):
            return
        print(full, flush=True)
        if self._fh:
            self._fh.write(full + "\n")
            self._fh.flush()

    def info(self, msg): self._write("INFO", msg)
    def warn(self, msg): self._write("WARN", msg)
    def error(self, msg): self._write("ERROR", msg)
    def debug(self, msg):
        if self.level in ("debug",):
            self._write("DEBUG", msg)
    def stream(self, msg): self._write("STRM", msg)


def hexdump(data, offset=0):
    lines = []
    for i in range(0, len(data), 16):
        chunk = data[i:i+16]
        hex_str = " ".join(f"{b:02x}" for b in chunk).ljust(47)
        ascii_str = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        lines.append(f" {offset + i:04x}: {hex_str} {ascii_str}")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════
# 代理核心
# ═══════════════════════════════════════════════════════════

class ProxyServer:
    def __init__(self, cfg):
        self.cfg = cfg
        self.log = Logger(cfg)
        self.target = cfg["target"]
        self.listen_port = cfg["listen_port"]
        self.listen_host = cfg["listen_host"]
        self.proxy_timeout = cfg["proxy"]["timeout"]
        self.allowed_models = cfg["proxy"]["allowed_models"]

    def dump_io(self, direction, method_or_status, path_or_reason, headers, body, tag=""):
        """打印请求/响应详情

        tag 标记数据流位置:
          "①→②" = 客户端原始请求(注入前)
          "④"   = 改造后的上游请求
          "⑧→⑨" = 上游原始响应(透传前)
        """
        if isinstance(headers, dict):
            header_items = list(headers.items())
        else:
            header_items = list(headers)

        if direction == "IN":
            req_line = f"{method_or_status} {path_or_reason} HTTP/1.1"
        else:
            req_line = f"HTTP/1.1 {method_or_status} {path_or_reason}"

        header_lines = [f"{k}: {v}" for k, v in header_items]
        raw_bytes = (req_line + "\r\n" + "\r\n".join(header_lines) + "\r\n\r\n").encode()
        if body:
            raw_bytes += body
        size = len(raw_bytes)

        tag_display = f" [{tag}]" if tag else ""
        emoji_map = {"①→②": "🧩", "④": "⚡", "⑧→⑨": "💬"}
        emoji = emoji_map.get(tag, "📥" if direction == "IN" else "📤")
        self.log.info(f"{emoji}{tag_display} {direction} ({size} bytes)")
        self.log.debug(f"  RAW: {raw_bytes[:self.log.max_body].decode('utf-8', 'replace')}")
        if self.log.hex_dump:
            self.log.debug(f"  HEX:\n{hexdump(raw_bytes[:self.log.max_body])}")

    def _connect(self):
        """创建到后端的连接"""
        if self.target["ssl"]:
            ctx = ssl_module.create_default_context()
            return httplib.HTTPSConnection(
                self.target["host"], self.target["port"],
                timeout=self.proxy_timeout, context=ctx
            )
        else:
            return httplib.HTTPConnection(
                self.target["host"], self.target["port"],
                timeout=self.proxy_timeout
            )

    def _build_headers(self, req_headers_dict, body):
        """构建上游请求头"""
        headers = {}
        for k, v in req_headers_dict.items():
            kl = k.lower()
            if kl not in ("host", "connection", "transfer-encoding", "content-length"):
                headers[k] = v
        headers["Authorization"] = f"Bearer {self.target['api_key']}"
        headers["Host"] = f"{self.target['host']}:{self.target['port']}"

        # 模型白名单检查
        if self.allowed_models:
            try:
                req_json = json.loads(body)
                model = req_json.get("model", "")
                if model and model not in self.allowed_models:
                    self.log.warn(f"模型 '{model}' 不在白名单中: {self.allowed_models}")
            except:
                pass
        return headers

    def proxy_normal(self, path, req_body, req_headers):
        """非流式转发"""
        conn = self._connect()
        try:
            headers = self._build_headers(req_headers, req_body)
            # ④ 记录改造后的上游请求
            self.dump_io("OUT", "POST", path, headers, req_body, tag="④")
            conn.request("POST", path, body=req_body, headers=headers)
            resp = conn.getresponse()
            resp_body = resp.read()
            out_headers = [(k, v) for k, v in resp.getheaders()
                          if k.lower() not in ("transfer-encoding", "content-encoding")]
            return resp.status, out_headers, resp_body
        except Exception as e:
            err = json.dumps({"error": str(e), "target": f"{self.target['host']}:{self.target['port']}"}).encode()
            self.log.error(f"代理失败: {e}")
            out_headers = [("Content-Type", "application/json")]
            return 502, out_headers, err
        finally:
            conn.close()

    def proxy_stream(self, path, req_body, req_headers, wfile):
        """流式 SSE 转发"""
        conn = self._connect()
        try:
            headers = self._build_headers(req_headers, req_body)
            # ④ 记录改造后的上游请求
            self.dump_io("OUT", "POST", path, headers, req_body, tag="④")
            conn.request("POST", path, body=req_body, headers=headers)
            resp = conn.getresponse()

            self.log.stream(f"后端状态: {resp.status} {resp.reason}")

            if resp.status != 200:
                err_body = resp.read().decode("utf-8", errors="replace")[:500]
                self.log.error(f"后端错误: {err_body}")
                wfile.write(f"data: {json.dumps({'error': err_body})}\n\n".encode())
                wfile.write(b"data: [DONE]\n\n")
                wfile.flush()
                return

            # SSE 响应头
            out_headers = [
                ("Content-Type", "text/event-stream; charset=utf-8"),
                ("Cache-Control", "no-cache"),
                ("Connection", "keep-alive"),
                ("Access-Control-Allow-Origin", "*"),
            ]

            wfile.write(b"HTTP/1.1 200 OK\r\n")
            for k, v in out_headers:
                wfile.write(f"{k}: {v}\r\n".encode())
            wfile.write(b"\r\n")
            wfile.flush()

            self.dump_io("OUT", 200, "OK", out_headers, None, tag="⑧→⑨")

            chunk_count = 0
            while True:
                chunk = resp.read(4096)
                if not chunk:
                    break
                try:
                    wfile.write(chunk)
                    wfile.flush()
                    chunk_count += 1
                    if chunk_count <= 3 or chunk_count % 30 == 0:
                        trimmed = chunk.decode("utf-8", "replace")[:120].replace("\n", "\\n")
                        self.log.stream(f"chunk #{chunk_count}: {trimmed}")
                except (BrokenPipeError, ConnectionResetError):
                    self.log.stream(f"客户端断开 (chunk #{chunk_count})")
                    break

            self.log.stream(f"流结束, {chunk_count} chunks")
        except Exception as e:
            self.log.error(f"流式错误: {e}")
            try:
                wfile.write(f"data: {json.dumps({'error': str(e)})}\n\n".encode())
                wfile.write(b"data: [DONE]\n\n")
                wfile.flush()
            except:
                pass
        finally:
            conn.close()


# ═══════════════════════════════════════════════════════════
# HTTP 请求处理器
# ═══════════════════════════════════════════════════════════

def make_handler(proxy):
    class ProxyHandler(http.server.BaseHTTPRequestHandler):
        def do_OPTIONS(self):
            self._cors()
            self.send_response(200)
            self.end_headers()

        def do_GET(self):
            if self.path == "/health":
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self._cors()
                self.end_headers()
                self.wfile.write(json.dumps({
                    "status": "ok",
                    "ts": proxy.log.ts(),
                    "target": f"{proxy.target['host']}:{proxy.target['port']}",
                    "target_description": proxy.target.get("description", ""),
                    "listening": f"{proxy.listen_host}:{proxy.listen_port}",
                    "ssl": proxy.target["ssl"],
                }).encode())
                return
            self._proxy_get(self.path)

        def _proxy_get(self, path):
            conn = proxy._connect()
            try:
                headers = {
                    "Authorization": f"Bearer {proxy.target['api_key']}",
                }
                conn.request("GET", path, headers=headers)
                resp = conn.getresponse()
                resp_body = resp.read()
                out_h = [(k, v) for k, v in resp.getheaders()
                        if k.lower() not in ("transfer-encoding", "content-encoding")]
                proxy.dump_io("OUT", resp.status, resp.reason, out_h, resp_body)
                self.send_response(resp.status)
                for k, v in out_h:
                    self.send_header(k, v)
                self._cors()
                self.end_headers()
                self.wfile.write(resp_body)
            except Exception as e:
                err = json.dumps({"error": str(e)}).encode()
                proxy.log.error(f"GET 代理失败: {e}")
                self.send_response(502)
                self.send_header("Content-Type", "application/json")
                self._cors()
                self.end_headers()
                self.wfile.write(err)
            finally:
                conn.close()

        def do_POST(self):
            content_len = int(self.headers.get("Content-Length", 0))
            req_body = self.rfile.read(content_len) if content_len > 0 else b""

            # ①→② 记录客户端原始请求（注入前）
            proxy.dump_io("IN", "POST", self.path, dict(self.headers.items()), req_body, tag="①→②")

            # 判断是否流式
            is_stream = False
            try:
                req_json = json.loads(req_body)
                is_stream = req_json.get("stream", False)
            except:
                pass

            if is_stream:
                proxy.proxy_stream(self.path, req_body, dict(self.headers.items()), self.wfile)
            else:
                status, headers, resp_body = proxy.proxy_normal(self.path, req_body, dict(self.headers.items()))
                # ⑧→⑨ 记录上游原始响应（透传给客户端前）
                proxy.dump_io("OUT", status, "OK" if status == 200 else "Bad Gateway",
                              headers, resp_body, tag="⑧→⑨")
                self.send_response(status)
                for k, v in headers:
                    if k.lower() not in ("transfer-encoding", "content-encoding", "content-length"):
                        self.send_header(k, v)
                self._cors()
                self.end_headers()
                self.wfile.write(resp_body)

        def _cors(self):
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "*")

        def log_message(self, fmt, *args):
            pass

    return ProxyHandler


# ═══════════════════════════════════════════════════════════
# 主入口
# ═══════════════════════════════════════════════════════════

def main():
    cfg = load_config()
    cfg = parse_cli(cfg)
    proxy = ProxyServer(cfg)

    handler_class = make_handler(proxy)
    server = http.server.HTTPServer((proxy.listen_host, proxy.listen_port), handler_class)

    target = proxy.target
    desc = proxy.target.get("description", "")
    print("=" * 60, flush=True)
    proxy.log.info(f"🚀 Qwen Proxy 运行中")
    proxy.log.info(f"   本地:  {proxy.listen_host}:{proxy.listen_port}")
    proxy.log.info(f"   目标:  {target['host']}:{target['port']} {'🔒 SSL' if target['ssl'] else '🔓 HTTP'} ")
    proxy.log.info(f"   名称:  {target.get('host')}")
    if target.get("api_key"):
        proxy.log.info(f"   API Key: ...{target['api_key'][-6:]}")
    if desc:
        proxy.log.info(f"   说明:  {desc}")
    if proxy.log.level == "debug":
        proxy.log.info(f"   模式:  🐛 DEBUG (hex dump 开启)")
    if proxy.log.log_file:
        proxy.log.info(f"   日志:  {proxy.log.log_file}")
    if proxy.allowed_models:
        proxy.log.info(f"   模型白名单: {proxy.allowed_models}")
    if proxy.proxy_timeout != 300:
        proxy.log.info(f"   超时:  {proxy.proxy_timeout}s")
    print("=" * 60, flush=True)

    def shutdown(sig, frame):
        proxy.log.info("收到退出信号, 关闭...")
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        proxy.log.info("服务器已关闭")


if __name__ == "__main__":
    main()
