# Qwen Proxy — 可配置的 OpenAI 兼容 API 代理

纯 Python 标准库实现，零依赖。支持多种配置方式，可转发到任意上游 API。

## 配置方式（优先级递增）

```
config.yaml  <  环境变量  <  CLI 参数
```

### 方式 1: config.yaml（配置文件）

编辑 `config.yaml`，可以定义多个目标并切换：

```yaml
targets:
  qwen3.6-35b:
    host: "58.23.129.98"
    port: 8001
    api_key: "sk-xxx"

  deepseek:
    host: "api.deepseek.com"
    port: 443
    api_key: "sk-yyy"
    ssl: true

default_target: "qwen3.6-35b"
```

### 方式 2: 环境变量

```bash
# 按名称选择 config.yaml 中定义的目标
TARGET=deepseek python3 proxy.py

# 或直接指定主机和端口
TARGET_HOST=api.deepseek.com TARGET_PORT=443 API_KEY=sk-xxx SSL=true python3 proxy.py

# 改监听端口
LISTEN_PORT=9999 python3 proxy.py
```

### 方式 3: CLI 参数（最高优先级）

```bash
# 选择配置文件中的目标
python3 proxy.py --target deepseek

# 直接指定
python3 proxy.py --target-host api.deepseek.com --target-port 443 --api-key sk-xxx --ssl

# 调试模式（打印 hex dump）
python3 proxy.py --debug

# 写日志到文件
python3 proxy.py --log-file /tmp/proxy.log

# 完整示例：覆盖所有
python3 proxy.py \
  --target-host 58.23.129.98 \
  --target-port 8001 \
  --api-key sk-78sadn09bjawde123e \
  --listen 8765 \
  --timeout 600 \
  --debug
```

## 快速开始

```bash
# 默认使用 config.yaml 中的配置
python3 proxy.py

# 后台运行
nohup python3 proxy.py > /tmp/proxy.log 2>&1 &

# 检查运行状态
curl http://localhost:8765/health
```

## API 端点

| 端点 | 方法 | 说明 |
|------|------|------|
| `/v1/chat/completions` | POST | 聊天补全（支持 `stream: true`） |
| `/v1/models` | GET | 列出可用模型 |
| `/health` | GET | 健康检查（含当前目标信息） |

### 使用示例

```bash
# 非流式
curl -X POST http://localhost:8765/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"qwen3.6-35b","messages":[{"role":"user","content":"你好"}],"max_tokens":100}'

# 流式
curl -N -X POST http://localhost:8765/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"qwen3.6-35b","messages":[{"role":"user","content":"你好"}],"stream":true}'

# 健康检查（会显示当前目标信息）
curl http://localhost:8765/health

# 模型列表
curl http://localhost:8765/v1/models
```

## 日志

日志级别：

- `info`（默认）— 请求总数、状态码、流式chunk数
- `debug` — 加原始 body 内容
- `warning` — 只显示警告和错误

Debug 模式开启 hex dump 可像 Wireshark 一样看原始字节。

## 文件结构

```
proxy-config/
├── config.yaml       # 配置文件（定义多个目标）
├── proxy.py          # 代理主程序
├── README.md         # 本文件
└── .gitignore
```

## 依赖

**零依赖** — 内置 YAML 解析器，只需 Python 3 标准库即可运行。
